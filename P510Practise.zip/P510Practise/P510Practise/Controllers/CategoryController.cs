﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using P510Practise.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using P510Practise.ViewModels;

namespace P510Practise.Controllers
{
    public class CategoryController : Controller
    {
        private readonly AppDbContext _dbContext;

        public CategoryController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> Index(int? id)
        {
            if (id == null)
                return NotFound();

            var category = await _dbContext.Categories.FirstOrDefaultAsync(x => x.Id == id);
            if (category == null)
                return NotFound();

            var categories = await _dbContext.Categories.Where(x => x.IsDeleted == false && x.IsMain == true)
                .Include(x => x.Children.Where(y => y.IsDeleted == false)).ToListAsync();

            var categoryViewModel = new CategoryViewModel
            {
                Category = category,
                Categories = categories
            };

            return View(categoryViewModel);
        }
    }
}
