﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using P510Practise.DataAccessLayer;

namespace P510Practise.Areas.AdminPanel.Controllers
{
    [Area("AdminPanel")]
    public class CategoryController : Controller
    {
        private readonly AppDbContext _dbContext;

        public CategoryController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IActionResult> Index()
        {
            var categories = await _dbContext.Categories.Where(x => x.IsDeleted == false).ToListAsync();

            return View(categories);
        }

        public async Task<IActionResult> Create()
        {
            ViewBag.ParentCategories = await _dbContext.Categories.
                Where(x => x.IsDeleted == false && x.IsMain == true).ToListAsync();

            return View();
        }
    }
}
